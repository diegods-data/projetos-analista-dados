# Projeto 4 – Dashboard de KPIs de Marketing

Este projeto demonstra como construir consultas SQL para um dashboard de indicadores de marketing, incluindo taxa de conversão, custo de aquisição de clientes (CAC) e retorno sobre investimento (ROI) por campanha. O objetivo é analisar dados de campanhas, cliques e vendas para gerar insights que apoiem decisões de marketing.

## Estrutura do repositório

```
project_4_dashboard_kpis_marketing/
├── data/
│   ├── campaigns.csv        # Dados fictícios de campanhas de marketing
│   ├── clicks.csv          # Dados de cliques em campanhas
│   └── sales.csv           # Dados de vendas geradas a partir das campanhas
├── queries/
│   ├── create_tables.sql    # Scripts para criação das tabelas no banco
│   └── dashboard_queries.sql # Consultas SQL para métricas de KPI
└── README.md                # Este arquivo de documentação
```

## Dados de exemplo

Os dados são armazenados em arquivos CSV na pasta `data`. Estes conjuntos são fictícios e servem apenas como exemplo para a construção das consultas.

### campaigns.csv

| campaign_id | name             | start_date | end_date   | budget | channel |
|------------:|------------------|------------|------------|--------|---------|
| 1           | Black Friday     | 2025-11-25 | 2025-11-30 | 5000   | Email   |
| 2           | Summer Sale      | 2025-01-05 | 2025-01-31 | 3000   | Social  |
| 3           | Holiday Specials | 2025-12-15 | 2025-12-31 | 7000   | Display |

### clicks.csv

| click_id | campaign_id | click_date | user_id |
|---------:|------------:|-----------:|--------:|
| 101      | 1           | 2025-11-26 | 1       |
| 102      | 1           | 2025-11-27 | 2       |
| 103      | 2           | 2025-01-10 | 3       |
| 104      | 3           | 2025-12-20 | 4       |

### sales.csv

| sale_id | campaign_id | sale_date  | revenue | user_id |
|--------:|------------:|-----------:|--------:|--------:|
| 201     | 1           | 2025-11-28 | 300     | 1       |
| 202     | 2           | 2025-01-12 | 150     | 3       |
| 203     | 3           | 2025-12-22 | 500     | 4       |
| 204     | 1           | 2025-11-29 | 250     | 2       |

## Scripts SQL

### create_tables.sql

Contém as instruções SQL para criação das tabelas `campaigns`, `clicks` e `sales` em um banco de dados relacional. Ajuste conforme o dialeto de SQL que utilizar.

### dashboard_queries.sql

Este arquivo agrupa consultas que calculam diferentes métricas de marketing:

1. **Taxa de conversão (conversion rate)** – Relação entre número de vendas e número de cliques por campanha.
2. **CAC (Custo de Aquisição de Clientes)** – Orçamento investido dividido pelo número de clientes adquiridos (vendas) por campanha.
3. **ROI (Retorno sobre Investimento)** – (Receita total - orçamento) dividido pelo orçamento.

Essas consultas podem ser executadas em sistemas como PostgreSQL, MySQL ou SQLite. Ajuste a sintaxe conforme o seu SGBD.

## Como utilizar

1. Crie um banco de dados relacional (por exemplo, SQLite ou PostgreSQL).
2. Execute o script `queries/create_tables.sql` para criar as tabelas.
3. Importe os arquivos CSV da pasta `data` para suas respectivas tabelas (dependendo do SGBD, utilize ferramentas de importação de dados).
4. Execute as consultas em `queries/dashboard_queries.sql` para gerar as métricas de KPI.

## Contribuições

Sinta‑se à vontade para aprimorar este projeto com mais métricas, tabelas ou visualizações. Abra um pull request ou issue no GitHub caso deseje contribuir.
