-- Criação das tabelas para o dashboard de KPIs de marketing
CREATE TABLE campaigns (
  campaign_id INTEGER PRIMARY KEY,
  name TEXT,
  start_date DATE,
  end_date DATE,
  budget REAL,
  channel TEXT
);

CREATE TABLE clicks (
  click_id INTEGER PRIMARY KEY,
  campaign_id INTEGER,
  click_date DATE,
  user_id INTEGER,
  FOREIGN KEY (campaign_id) REFERENCES campaigns(campaign_id)
);

CREATE TABLE sales (
  sale_id INTEGER PRIMARY KEY,
  campaign_id INTEGER,
  sale_date DATE,
  revenue REAL,
  user_id INTEGER,
  FOREIGN KEY (campaign_id) REFERENCES campaigns(campaign_id)
);

-- Insira dados utilizando instruções INSERT ou ferramentas de importação
