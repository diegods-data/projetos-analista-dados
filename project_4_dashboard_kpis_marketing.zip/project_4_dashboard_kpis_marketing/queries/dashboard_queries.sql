-- Taxa de conversão: relação entre o número de vendas e o número de cliques por campanha
SELECT
  ca.campaign_id,
  ca.name,
  COUNT(DISTINCT s.sale_id) * 1.0 / NULLIF(COUNT(DISTINCT cl.click_id), 0) AS conversion_rate
FROM campaigns ca
LEFT JOIN clicks cl ON ca.campaign_id = cl.campaign_id
LEFT JOIN sales s ON ca.campaign_id = s.campaign_id
GROUP BY ca.campaign_id, ca.name;

-- CAC (Custo de Aquisição de Clientes): orçamento dividido pelo número de clientes adquiridos
SELECT
  ca.campaign_id,
  ca.name,
  ca.budget / NULLIF(COUNT(DISTINCT s.user_id), 0) AS cac
FROM campaigns ca
LEFT JOIN sales s ON ca.campaign_id = s.campaign_id
GROUP BY ca.campaign_id, ca.name, ca.budget;

-- ROI (Retorno sobre investimento): (receita total - orçamento) / orçamento
SELECT
  ca.campaign_id,
  ca.name,
  (SUM(s.revenue) - ca.budget) / ca.budget AS roi
FROM campaigns ca
LEFT JOIN sales s ON ca.campaign_id = s.campaign_id
GROUP BY ca.campaign_id, ca.name, ca.budget;
