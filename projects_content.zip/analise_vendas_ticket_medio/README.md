# Analise Vendas Ticket Medio

**Objetivo:** Análise de vendas para identificar produtos mais rentáveis e calcular ticket médio por cliente.

## Estrutura de Dados
### pedidos.csv
Columns: id_pedido, id_cliente, valor_total, data

### produtos.csv
Columns: id_produto, preco, categoria

## Consultas SQL Principais
### Query 1
``sql
-- Top 10 produtos mais vendidos
SELECT p.id_produto, p.preco, p.categoria, SUM(p.valor_total) AS total_vendas
FROM pedidos p
GROUP BY p.id_produto, p.preco, p.categoria
ORDER BY total_vendas DESC
LIMIT 10;
```

### Query 2
``sql
-- Ticket médio por cliente
SELECT id_cliente, AVG(valor_total) AS ticket_medio
FROM pedidos
GROUP BY id_cliente
ORDER BY ticket_medio DESC;
```

## Benefício para a Empresa
Este projeto fornece insights valiosos para apoiar a tomada de decisão baseada em dados.

## Como Publicar
Organize as pastas `data/`, `sql/`, `python/` e `dashboard/` conforme necessário. Inclua scripts SQL, notebooks em Python (quando aplicável) e captures do dashboard.
