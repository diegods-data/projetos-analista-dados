-- Top 10 produtos mais vendidos
SELECT p.id_produto, p.preco, p.categoria, SUM(p.valor_total) AS total_vendas
FROM pedidos p
GROUP BY p.id_produto, p.preco, p.categoria
ORDER BY total_vendas DESC
LIMIT 10;
