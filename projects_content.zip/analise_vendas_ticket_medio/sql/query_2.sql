-- Ticket médio por cliente
SELECT id_cliente, AVG(valor_total) AS ticket_medio
FROM pedidos
GROUP BY id_cliente
ORDER BY ticket_medio DESC;
