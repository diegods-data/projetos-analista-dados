-- Tempo médio de resposta (em dias)
SELECT AVG(DATE_PART('day', data_fechamento - data_abertura)) AS tempo_medio_resposta
FROM chamados;
