-- Chamados mais recorrentes por categoria
SELECT categoria, COUNT(*) AS quantidade
FROM chamados
GROUP BY categoria
ORDER BY quantidade DESC;
