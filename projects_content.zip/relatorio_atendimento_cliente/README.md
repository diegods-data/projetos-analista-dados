# Relatorio Atendimento Cliente

**Objetivo:** Relatório de atendimento ao cliente medindo tempo de resposta e categorias de chamados.

## Estrutura de Dados
### data.csv
Columns: id, cliente, data_abertura, data_fechamento, categoria, satisfacao

## Consultas SQL Principais
### Query 1
``sql
-- Tempo médio de resposta (em dias)
SELECT AVG(DATE_PART('day', data_fechamento - data_abertura)) AS tempo_medio_resposta
FROM chamados;
```

### Query 2
``sql
-- Chamados mais recorrentes por categoria
SELECT categoria, COUNT(*) AS quantidade
FROM chamados
GROUP BY categoria
ORDER BY quantidade DESC;
```

## Benefício para a Empresa
Este projeto fornece insights valiosos para apoiar a tomada de decisão baseada em dados.

## Como Publicar
Organize as pastas `data/`, `sql/`, `python/` e `dashboard/` conforme necessário. Inclua scripts SQL, notebooks em Python (quando aplicável) e captures do dashboard.
