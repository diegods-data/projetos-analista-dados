# Previsão de receita com séries temporais

import pandas as pd
# import Prophet or statsmodels here (instalar conforme necessário)

# carregar dados de vendas
df = pd.read_csv('../data/data.csv')

# agrupar receita por mês
df['data'] = pd.to_datetime(df['data'])
df['mes'] = df['data'].dt.to_period('M')
receita_mensal = df.groupby('mes')['valor'].sum().reset_index()

# Aqui, você pode ajustar um modelo de previsão (ex.: Prophet ou ARIMA) baseado na coluna 'receita_mensal'
# Exemplo (pseudocódigo):
# from prophet import Prophet
# model = Prophet()
# model.fit(receita_mensal.rename(columns={'mes':'ds','valor':'y'}))
# future = model.make_future_dataframe(periods=6, freq='M')
# forecast = model.predict(future)

print(receita_mensal)
