-- Taxa de crescimento mensal
WITH receita AS (
    SELECT DATE_TRUNC('month', data) AS mes,
           SUM(valor) AS receita_mensal
    FROM vendas
    GROUP BY mes
)
SELECT mes,
       receita_mensal,
       receita_mensal - LAG(receita_mensal) OVER (ORDER BY mes) AS variacao,
       (receita_mensal - LAG(receita_mensal) OVER (ORDER BY mes)) / NULLIF(LAG(receita_mensal) OVER (ORDER BY mes), 0) * 100 AS perc_variacao
FROM receita;
