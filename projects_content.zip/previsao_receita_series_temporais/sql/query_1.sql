-- Receita agregada por mês
SELECT DATE_TRUNC('month', data) AS mes,
       SUM(valor) AS receita_mensal
FROM vendas
GROUP BY mes
ORDER BY mes;
