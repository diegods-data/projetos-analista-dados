# Previsao Receita Series Temporais

**Objetivo:** Previsão de receitas com séries temporais utilizando exportação de dados SQL e modelagem em Python.

## Estrutura de Dados
### data.csv
Columns: id_venda, data, valor, produto, canal

## Consultas SQL Principais
### Query 1
``sql
-- Receita agregada por mês
SELECT DATE_TRUNC('month', data) AS mes,
       SUM(valor) AS receita_mensal
FROM vendas
GROUP BY mes
ORDER BY mes;
```

### Query 2
``sql
-- Taxa de crescimento mensal
WITH receita AS (
    SELECT DATE_TRUNC('month', data) AS mes,
           SUM(valor) AS receita_mensal
    FROM vendas
    GROUP BY mes
)
SELECT mes,
       receita_mensal,
       receita_mensal - LAG(receita_mensal) OVER (ORDER BY mes) AS variacao,
       (receita_mensal - LAG(receita_mensal) OVER (ORDER BY mes)) / NULLIF(LAG(receita_mensal) OVER (ORDER BY mes), 0) * 100 AS perc_variacao
FROM receita;
```

## Benefício para a Empresa
Este projeto fornece insights valiosos para apoiar a tomada de decisão baseada em dados.

## Como Publicar
Organize as pastas `data/`, `sql/`, `python/` e `dashboard/` conforme necessário. Inclua scripts SQL, notebooks em Python (quando aplicável) e captures do dashboard.
