-- Total de entradas e saídas por mês
SELECT DATE_TRUNC('month', data) AS mes,
       SUM(valor) FILTER (WHERE tipo = 'entrada') AS total_entradas,
       SUM(valor) FILTER (WHERE tipo = 'saida')   AS total_saidas
FROM transacoes
GROUP BY mes
ORDER BY mes;
