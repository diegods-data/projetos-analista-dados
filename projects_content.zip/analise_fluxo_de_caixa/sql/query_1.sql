-- Soma entradas e saídas por mês
SELECT DATE_TRUNC('month', data) AS mes,
       SUM(CASE WHEN tipo = 'entrada' THEN valor ELSE -valor END) AS saldo_mensal
FROM transacoes
GROUP BY mes
ORDER BY mes;
