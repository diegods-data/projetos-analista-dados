# Analise Fluxo De Caixa

**Objetivo:** Análise de fluxo de caixa para monitoramento de entradas e saídas e cálculo de saldo mensal.

## Estrutura de Dados
### data.csv
Columns: id, data, tipo, valor, categoria, cliente_id

## Consultas SQL Principais
### Query 1
``sql
-- Soma entradas e saídas por mês
SELECT DATE_TRUNC('month', data) AS mes,
       SUM(CASE WHEN tipo = 'entrada' THEN valor ELSE -valor END) AS saldo_mensal
FROM transacoes
GROUP BY mes
ORDER BY mes;
```

### Query 2
``sql
-- Total de entradas e saídas por mês
SELECT DATE_TRUNC('month', data) AS mes,
       SUM(valor) FILTER (WHERE tipo = 'entrada') AS total_entradas,
       SUM(valor) FILTER (WHERE tipo = 'saida')   AS total_saidas
FROM transacoes
GROUP BY mes
ORDER BY mes;
```

## Benefício para a Empresa
Este projeto fornece insights valiosos para apoiar a tomada de decisão baseada em dados.

## Como Publicar
Organize as pastas `data/`, `sql/`, `python/` e `dashboard/` conforme necessário. Inclua scripts SQL, notebooks em Python (quando aplicável) e captures do dashboard.
