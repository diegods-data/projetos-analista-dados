-- Tempo médio por tarefa
SELECT AVG(DATE_PART('day', data_fim - data_inicio)) AS tempo_medio_dias
FROM tarefas
WHERE status = 'concluída';
