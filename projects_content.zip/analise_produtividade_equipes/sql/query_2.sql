-- Quantidade de tarefas concluídas por funcionário
SELECT id_funcionario, COUNT(*) AS tarefas_concluidas
FROM tarefas
WHERE status = 'concluída'
GROUP BY id_funcionario
ORDER BY tarefas_concluidas DESC;
