# Analise Produtividade Equipes

**Objetivo:** Análise de produtividade de equipes medindo tarefas concluídas e tempos de execução.

## Estrutura de Dados
### data.csv
Columns: id_tarefa, id_funcionario, status, data_inicio, data_fim

## Consultas SQL Principais
### Query 1
``sql
-- Tempo médio por tarefa
SELECT AVG(DATE_PART('day', data_fim - data_inicio)) AS tempo_medio_dias
FROM tarefas
WHERE status = 'concluída';
```

### Query 2
``sql
-- Quantidade de tarefas concluídas por funcionário
SELECT id_funcionario, COUNT(*) AS tarefas_concluidas
FROM tarefas
WHERE status = 'concluída'
GROUP BY id_funcionario
ORDER BY tarefas_concluidas DESC;
```

## Benefício para a Empresa
Este projeto fornece insights valiosos para apoiar a tomada de decisão baseada em dados.

## Como Publicar
Organize as pastas `data/`, `sql/`, `python/` e `dashboard/` conforme necessário. Inclua scripts SQL, notebooks em Python (quando aplicável) e captures do dashboard.
