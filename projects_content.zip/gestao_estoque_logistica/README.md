# Gestao Estoque Logistica

**Objetivo:** Monitoramento de estoque e otimização de logística identificando produtos abaixo do estoque mínimo.

## Estrutura de Dados
### estoque.csv
Columns: id_produto, quantidade_atual, quantidade_minima

### fornecedores.csv
Columns: id_fornecedor, prazo_entrega_dias

## Consultas SQL Principais
### Query 1
``sql
-- Identificar produtos com nível de estoque crítico
SELECT id_produto, quantidade_atual, quantidade_minima
FROM estoque
WHERE quantidade_atual < quantidade_minima;
```

### Query 2
``sql
-- Tempo médio de reposição
SELECT AVG(prazo_entrega_dias) AS tempo_medio_entrega
FROM fornecedores;
```

## Benefício para a Empresa
Este projeto fornece insights valiosos para apoiar a tomada de decisão baseada em dados.

## Como Publicar
Organize as pastas `data/`, `sql/`, `python/` e `dashboard/` conforme necessário. Inclua scripts SQL, notebooks em Python (quando aplicável) e captures do dashboard.
