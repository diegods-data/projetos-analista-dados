-- Identificar produtos com nível de estoque crítico
SELECT id_produto, quantidade_atual, quantidade_minima
FROM estoque
WHERE quantidade_atual < quantidade_minima;
