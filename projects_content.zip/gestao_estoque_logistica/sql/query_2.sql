-- Tempo médio de reposição
SELECT AVG(prazo_entrega_dias) AS tempo_medio_entrega
FROM fornecedores;
