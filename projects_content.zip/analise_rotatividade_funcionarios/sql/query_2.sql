-- Tempo médio de permanência (em dias)
SELECT AVG(DATE_PART('day', data_saida - data_admissao)) AS tempo_medio_dias
FROM funcionarios
WHERE data_saida IS NOT NULL;
