-- Turnover por departamento
SELECT departamento,
       COUNT(CASE WHEN data_saida IS NOT NULL THEN 1 END) * 100.0 / COUNT(*) AS turnover_percentual
FROM funcionarios
GROUP BY departamento;
