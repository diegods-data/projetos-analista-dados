# Analise Rotatividade Funcionarios

**Objetivo:** Análise de rotatividade de funcionários para calcular turnover e tempo médio de permanência.

## Estrutura de Dados
### data.csv
Columns: id, departamento, data_admissao, data_saida, salario

## Consultas SQL Principais
### Query 1
``sql
-- Turnover por departamento
SELECT departamento,
       COUNT(CASE WHEN data_saida IS NOT NULL THEN 1 END) * 100.0 / COUNT(*) AS turnover_percentual
FROM funcionarios
GROUP BY departamento;
```

### Query 2
``sql
-- Tempo médio de permanência (em dias)
SELECT AVG(DATE_PART('day', data_saida - data_admissao)) AS tempo_medio_dias
FROM funcionarios
WHERE data_saida IS NOT NULL;
```

## Benefício para a Empresa
Este projeto fornece insights valiosos para apoiar a tomada de decisão baseada em dados.

## Como Publicar
Organize as pastas `data/`, `sql/`, `python/` e `dashboard/` conforme necessário. Inclua scripts SQL, notebooks em Python (quando aplicável) e captures do dashboard.
