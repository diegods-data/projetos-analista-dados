# Dashboard Kpis Financeiros

**Objetivo:** Criação de um dashboard de KPIs financeiros (margem bruta, EBITDA, etc.) a partir de dados SQL.

## Estrutura de Dados
### receitas.csv
Columns: id, data, valor

### despesas.csv
Columns: id, data, valor

### investimentos.csv
Columns: id, data, valor

## Consultas SQL Principais
### Query 1
``sql
-- Receita e despesas por trimestre
SELECT DATE_TRUNC('quarter', data) AS trimestre,
       SUM(CASE WHEN tabela = 'receitas' THEN valor ELSE 0 END) AS total_receitas,
       SUM(CASE WHEN tabela = 'despesas' THEN valor ELSE 0 END) AS total_despesas
FROM (
    SELECT 'receitas' AS tabela, data, valor FROM receitas
    UNION ALL
    SELECT 'despesas' AS tabela, data, valor FROM despesas
) AS t
GROUP BY trimestre
ORDER BY trimestre;
```

### Query 2
``sql
-- Margem bruta mensal
WITH receita AS (
    SELECT DATE_TRUNC('month', data) AS mes, SUM(valor) AS total_receitas FROM receitas GROUP BY mes
),
     despesa AS (
    SELECT DATE_TRUNC('month', data) AS mes, SUM(valor) AS total_despesas FROM despesas GROUP BY mes
)
SELECT r.mes,
       r.total_receitas,
       d.total_despesas,
       r.total_receitas - d.total_despesas AS margem_bruta
FROM receita r
JOIN despesa d ON r.mes = d.mes;
```

## Benefício para a Empresa
Este projeto fornece insights valiosos para apoiar a tomada de decisão baseada em dados.

## Como Publicar
Organize as pastas `data/`, `sql/`, `python/` e `dashboard/` conforme necessário. Inclua scripts SQL, notebooks em Python (quando aplicável) e captures do dashboard.
