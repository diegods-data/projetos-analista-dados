-- Receita e despesas por trimestre
SELECT DATE_TRUNC('quarter', data) AS trimestre,
       SUM(CASE WHEN tabela = 'receitas' THEN valor ELSE 0 END) AS total_receitas,
       SUM(CASE WHEN tabela = 'despesas' THEN valor ELSE 0 END) AS total_despesas
FROM (
    SELECT 'receitas' AS tabela, data, valor FROM receitas
    UNION ALL
    SELECT 'despesas' AS tabela, data, valor FROM despesas
) AS t
GROUP BY trimestre
ORDER BY trimestre;
