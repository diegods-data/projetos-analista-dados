-- Margem bruta mensal
WITH receita AS (
    SELECT DATE_TRUNC('month', data) AS mes, SUM(valor) AS total_receitas FROM receitas GROUP BY mes
),
     despesa AS (
    SELECT DATE_TRUNC('month', data) AS mes, SUM(valor) AS total_despesas FROM despesas GROUP BY mes
)
SELECT r.mes,
       r.total_receitas,
       d.total_despesas,
       r.total_receitas - d.total_despesas AS margem_bruta
FROM receita r
JOIN despesa d ON r.mes = d.mes;
