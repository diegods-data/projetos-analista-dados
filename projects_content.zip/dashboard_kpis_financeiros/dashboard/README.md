## Dashboard KPIs Financeiros

Este diretório deve conter o arquivo do painel de controle (ex.: .pbix para Power BI ou .twbx para Tableau).
