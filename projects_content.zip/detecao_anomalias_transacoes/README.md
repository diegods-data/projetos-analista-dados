# Detecao Anomalias Transacoes

**Objetivo:** Detecção de anomalias em transações financeiras usando SQL e validação estatística em Python.

## Estrutura de Dados
### data.csv
Columns: id, data, valor, conta_origem, conta_destino

## Consultas SQL Principais
### Query 1
``sql
-- Transações acima de 2 desvios padrão da média
SELECT *
FROM transacoes
WHERE valor > (
    SELECT AVG(valor) + 2 * STDDEV(valor)
    FROM transacoes
);
```

### Query 2
``sql
-- Pico de movimentações em horários incomuns
SELECT data, valor
FROM transacoes
WHERE EXTRACT(HOUR FROM data) NOT BETWEEN 8 AND 18
  AND valor > (SELECT AVG(valor) FROM transacoes);
```

## Benefício para a Empresa
Este projeto fornece insights valiosos para apoiar a tomada de decisão baseada em dados.

## Como Publicar
Organize as pastas `data/`, `sql/`, `python/` e `dashboard/` conforme necessário. Inclua scripts SQL, notebooks em Python (quando aplicável) e captures do dashboard.
