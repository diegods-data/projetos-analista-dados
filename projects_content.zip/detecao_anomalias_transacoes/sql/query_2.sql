-- Pico de movimentações em horários incomuns
SELECT data, valor
FROM transacoes
WHERE EXTRACT(HOUR FROM data) NOT BETWEEN 8 AND 18
  AND valor > (SELECT AVG(valor) FROM transacoes);
