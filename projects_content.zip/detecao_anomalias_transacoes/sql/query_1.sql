-- Transações acima de 2 desvios padrão da média
SELECT *
FROM transacoes
WHERE valor > (
    SELECT AVG(valor) + 2 * STDDEV(valor)
    FROM transacoes
);
