# Detecção de anomalias em transações

import pandas as pd

# carregar dados de transações
df = pd.read_csv('../data/data.csv')

# Calcular estatísticas básicas
media = df['valor'].mean()
desvio = df['valor'].std()

# Definir limite de anomalia (2 desvios padrão acima da média)
limite = media + 2 * desvio

# Identificar transações suspeitas
anomalias = df[df['valor'] > limite]

print('Limite de anomalia:', limite)
print('Transações suspeitas:')
print(anomalias)
