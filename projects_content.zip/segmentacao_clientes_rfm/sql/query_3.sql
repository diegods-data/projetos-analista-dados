-- Cálculo monetário (total gasto)
SELECT id_cliente, SUM(valor) AS monetario
FROM compras
GROUP BY id_cliente;
