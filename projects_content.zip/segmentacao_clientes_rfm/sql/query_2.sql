-- Cálculo de frequência (número de compras)
SELECT id_cliente, COUNT(*) AS frequencia
FROM compras
GROUP BY id_cliente;
