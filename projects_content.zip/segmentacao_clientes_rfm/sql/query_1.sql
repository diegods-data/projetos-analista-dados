-- Cálculo de recência (dias desde a última compra)
SELECT c.id_cliente,
       DATE_PART('day', CURRENT_DATE - MAX(cp.data)) AS recencia
FROM clientes c
LEFT JOIN compras cp ON cp.id_cliente = c.id_cliente
GROUP BY c.id_cliente;
