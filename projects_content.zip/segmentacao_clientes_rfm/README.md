# Segmentacao Clientes Rfm

**Objetivo:** Segmentação de clientes utilizando a metodologia RFM (recência, frequência, monetário).

## Estrutura de Dados
### clientes.csv
Columns: id_cliente, nome, cidade

### compras.csv
Columns: id_compra, id_cliente, valor, data

## Consultas SQL Principais
### Query 1
``sql
-- Cálculo de recência (dias desde a última compra)
SELECT c.id_cliente,
       DATE_PART('day', CURRENT_DATE - MAX(cp.data)) AS recencia
FROM clientes c
LEFT JOIN compras cp ON cp.id_cliente = c.id_cliente
GROUP BY c.id_cliente;
```

### Query 2
``sql
-- Cálculo de frequência (número de compras)
SELECT id_cliente, COUNT(*) AS frequencia
FROM compras
GROUP BY id_cliente;
```

### Query 3
``sql
-- Cálculo monetário (total gasto)
SELECT id_cliente, SUM(valor) AS monetario
FROM compras
GROUP BY id_cliente;
```

## Benefício para a Empresa
Este projeto fornece insights valiosos para apoiar a tomada de decisão baseada em dados.

## Como Publicar
Organize as pastas `data/`, `sql/`, `python/` e `dashboard/` conforme necessário. Inclua scripts SQL, notebooks em Python (quando aplicável) e captures do dashboard.
